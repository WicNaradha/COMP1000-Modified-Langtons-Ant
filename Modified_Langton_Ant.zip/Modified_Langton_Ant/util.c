/* Following are the tags for comments colouring */

/* ! BUG: This is a BUG, __HEADING LINE___ */

/* ! BUG: This is a BUG, __HEADING LINE___
   ! The description continues to the next line (preceded with !)
   ! The description continues to the next line (preceded with !) */

/* HACK: This is a hack (single line) */

/* PERF: Performance improvement fix (single line) */

/* TODO: Something todo (single line) */

/* DEPRECATED: Deprecated code segment (single line)*/

/* ^ IMPORTANT: This is an important note (single line) */

/* ^ IMPORTANT: This is an important note, __HEADER__
   ^ The description continues to the next line (preceded with ^)
   ^ The description continues to the next line (preceded with ^) */

/* ? STUDY: This is a study note (single line) */

/* ? STUDY: This is an important note, __HEADER__
   ? The description continues to the next line (preceded with ?)
   ? The description continues to the next line (preceded with ?) */

int util_function()
{
        return 0;
}