#ifndef GAME_H
#define GAME_H

#include "macros.h"
#include "gstruct.h"
#include "inout.h"
#include "grids.h"
#include "newSleep.h"

#endif