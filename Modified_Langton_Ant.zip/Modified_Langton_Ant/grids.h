#ifndef GRID_H
#define GRID_H

#include "random.h"
#include "gstruct.h"
#include "macros.h"

/* Forward Declerations */
void updategame(GameStruct* data);

#endif