#ifndef COLOR_H
#define COLOR_H

#include "macros.h"

void setForeground(char * color, char bold);
void setBackground(char * color);
void printreset();

#endif